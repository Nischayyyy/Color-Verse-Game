#include <GL/glut.h>
#include <iostream>
#include <vector>
#include <cmath>

class Box {
public:
    float color[3];
    float position[2];

    Box(float r, float g, float b, float x, float y) {
        color[0] = r;
        color[1] = g;
        color[2] = b;
        position[0] = x;
        position[1] = y;
    }

    void draw(float boxSize) {
        glColor3fv(color);
        glBegin(GL_QUADS);
        glVertex2f(position[0], position[1]);
        glVertex2f(position[0] + boxSize, position[1]);
        glVertex2f(position[0] + boxSize, position[1] + boxSize);
        glVertex2f(position[0], position[1] + boxSize);
        glEnd();
    }
};

class Merge {
public:
    static bool areColorsEqual(float color1[3], float color2[3]) {
        return color1[0] == color2[0] && color1[1] == color2[1] && color1[2] == color2[2];
    }

    static void mergeBoxes(std::vector<Box>& boxes, int index1, int index2) {
        float mergedColor[3];
        for (int i = 0; i < 3; i++) {
            mergedColor[i] = std::min(boxes[index1].color[i] + boxes[index2].color[i], 1.0f);
        }

        boxes[index1].color[0] = mergedColor[0];
        boxes[index1].color[1] = mergedColor[1];
        boxes[index1].color[2] = mergedColor[2];
        boxes[index2] = boxes.back();
        boxes.pop_back();
    }
};

class Stack {
public:
    std::vector<Box> boxes;

    void push(Box box) {
        boxes.push_back(box);
    }

    void pop() {
        boxes.pop_back();
    }

    Box& top() {
        return boxes.back();
    }

    bool empty() {
        return boxes.empty();
    }
};

class GenerateBoxes {
public:
    static void generate(std::vector<Box>& boxes, int count) {
        for (int i = 0; i < count; ++i) {
            boxes.push_back(Box(1.0, 0.0, 0.0, i * 60.0, 300.0));
            boxes.push_back(Box(0.0, 1.0, 0.0, i * 60.0, 200.0));
            boxes.push_back(Box(0.0, 0.0, 1.0, i * 60.0, 100.0));
        }
    }
};

int screenWidth = 0;
int screenHeight = 0;
float boxSize = 50.0;
bool isDragging = false;
int selectedBox = -1;
Stack boxes;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    for (auto& box : boxes.boxes) {
        box.draw(boxSize);
    }

    glFlush();
}

void reshape(int width, int height) {
    screenWidth = width;
    screenHeight = height;
    glViewport(0, 0, screenWidth, screenHeight);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, screenWidth, 0, screenHeight, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void mouse(int button, int state, int x, int y) {
    y = screenHeight - y;
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            for (int i = 0; i < boxes.boxes.size(); ++i) {
                if (x >= boxes.boxes[i].position[0] && x <= boxes.boxes[i].position[0] + boxSize &&
                    y >= boxes.boxes[i].position[1] && y <= boxes.boxes[i].position[1] + boxSize) {
                    isDragging = true;
                    selectedBox = i;
                    break;
                }
            }
        }
        else if (state == GLUT_UP) {
            isDragging = false;
            selectedBox = -1;
        }
    }
}

void motion(int x, int y) {
    y = screenHeight - y;
    if (isDragging && selectedBox != -1) {
        boxes.boxes[selectedBox].position[0] = x - boxSize / 2;
        boxes.boxes[selectedBox].position[1] = y - boxSize / 2;

        if (boxes.boxes[selectedBox].position[0] < 0) boxes.boxes[selectedBox].position[0] = 0;
        if (boxes.boxes[selectedBox].position[1] < 0) boxes.boxes[selectedBox].position[1] = 0;
        if (boxes.boxes[selectedBox].position[0] > screenWidth - boxSize) boxes.boxes[selectedBox].position[0] = screenWidth - boxSize;
        if (boxes.boxes[selectedBox].position[1] > screenHeight - boxSize) boxes.boxes[selectedBox].position[1] = screenHeight - boxSize;

        for (int i = 0; i < boxes.boxes.size(); ++i) {
            if (i != selectedBox &&
                fabs(boxes.boxes[i].position[0] - boxes.boxes[selectedBox].position[0]) <= boxSize &&
                fabs(boxes.boxes[i].position[1] - boxes.boxes[selectedBox].position[1]) <= boxSize)
            {
                if (Merge::areColorsEqual(boxes.boxes[i].color, boxes.boxes[selectedBox].color)) {
                    boxes.boxes[selectedBox].position[0] = boxes.boxes[i].position[0];
                    boxes.boxes[selectedBox].position[1] = boxes.boxes[i].position[1] + boxSize;
                }
                else {
                    Merge::mergeBoxes(boxes.boxes, selectedBox, i);
                    isDragging = false;
                    selectedBox = -1;
                }
                break;
            }
        }

        glutPostRedisplay();
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    screenWidth = glutGet(GLUT_SCREEN_WIDTH);
    screenHeight = glutGet(GLUT_SCREEN_HEIGHT);
    glutInitWindowSize(screenWidth, screenHeight);
    glutCreateWindow("Drag and Drop Boxes");
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, screenWidth, 0, screenHeight, -1.0, 1.0);

    GenerateBoxes::generate(boxes.boxes, 10);

    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutReshapeFunc(reshape);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glutMainLoop();

    return EXIT_SUCCESS;
}