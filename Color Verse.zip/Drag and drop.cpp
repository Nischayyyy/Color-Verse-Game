#include <GL/glut.h>
#include <vector>
#include <cstdlib>
#include <ctime>

class Square {
public:
    float x1, y1, x2, y2;
    float r, g, b;

    Square(float x1, float y1, float x2, float y2, float r, float g, float b)
        : x1(x1), y1(y1), x2(x2), y2(y2), r(r), g(g), b(b) {}
};

class Boundary {
public:
    float x1, y1, x2, y2;
    float r, g, b;

    Boundary(float x1, float y1, float x2, float y2, float r, float g, float b)
        : x1(x1), y1(y1), x2(x2), y2(y2), r(r), g(g), b(b) {}
};

class SquareGenerator {
private:
    std::vector<Square> squares;
    std::vector<Boundary> boundaries;

public:
    std::vector<int> unusedBoundaries;
    std::vector<Square>& getSquares() {
        return squares;
    }

    SquareGenerator() {
        float bx1 = -0.65f, by1 = 0.6f, bx2 = -0.45f, by2 = 0.3f;
        boundaries = { {bx1,by1,bx2,by2, 1.0f, 1.0f, 1.0f} , 
                       {bx1 + 0.5f,by1,bx2 + 0.5f,by2, 1.0f, 1.0f, 1.0f}, 
                       {bx1 + 1.0f,by1,bx2 + 1.0f,by2, 1.0f, 1.0f, 1.0f}, 
                       {bx1,by1 - 0.35f,bx2,by2 - 0.35f, 1.0f, 1.0f, 1.0f}, 
                       {bx1 + 0.5f,by1 - 0.35f,bx2 + 0.5f,by2 - 0.35f, 1.0f, 1.0f, 1.0f}, 
                       {bx1 + 1.0f,by1 - 0.35f,bx2 + 1.0f,by2 - 0.35f, 1.0f, 1.0f, 1.0f},
                       {bx1,by1 - 0.7f,bx2,by2 - 0.7f, 1.0f, 1.0f, 1.0f},
                        {bx1 + 0.5f,by1 - 0.7f,bx2 + 0.5f,by2 - 0.7f, 1.0f, 1.0f, 1.0f},
                        {bx1 + 1.0f,by1 - 0.7f,bx2 + 1.0f,by2 - 0.7f, 1.0f, 1.0f, 1.0f} };

        initUnusedBoundaries();
        squares.push_back({ -0.9f, 0.9f, -0.7f, 0.6f, 1.0f, 0.0f, 0.0f });
    }

    void initUnusedBoundaries() {
        for (int i = 0; i < boundaries.size(); ++i) {
            unusedBoundaries.push_back(i);
        }
    }
    void generateSquare() {
        if (unusedBoundaries.empty()) {

            return;
        }

        int randIndex = rand() % unusedBoundaries.size();
        int boundaryIndex = unusedBoundaries[randIndex];
        Boundary& boundary = boundaries[boundaryIndex];
        unusedBoundaries.erase(unusedBoundaries.begin() + randIndex);
        float r = 0.0f;
        float g = 0.0f;
        float b = 0.0f;
        srand(time(NULL));
        int random_val = rand() % 3;
        r = (random_val == 0) ? 1.0f : 0.0f;
        g = (random_val == 1) ? 1.0f : 0.0f;
        b = (random_val == 2) ? 1.0f : 0.0f;

        squares.push_back({ boundary.x1, boundary.y1, boundary.x2, boundary.y2, r, g, b });
    }

    void draw() {
        for (auto& boundary : boundaries) {
            glColor3f(boundary.r, boundary.g, boundary.b);
            glBegin(GL_LINE_LOOP);
            glVertex2f(boundary.x1, boundary.y1);
            glVertex2f(boundary.x2, boundary.y1);
            glVertex2f(boundary.x2, boundary.y2);
            glVertex2f(boundary.x1, boundary.y2);
            glEnd();
        }

        for (size_t i = 0; i < squares.size(); ++i) {
            glColor3f(squares[i].r, squares[i].g, squares[i].b);
            glBegin(GL_POLYGON);
            glVertex2f(squares[i].x1, squares[i].y1);
            glVertex2f(squares[i].x2, squares[i].y1);
            glVertex2f(squares[i].x2, squares[i].y2);
            glVertex2f(squares[i].x1, squares[i].y2);
            glEnd();

            // Render the number on the square
            glColor3f(1.0f, 1.0f, 1.0f);
            glRasterPos2f((squares[i].x1 + squares[i].x2) / 2, (squares[i].y1 + squares[i].y2) / 2);
            glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '0' + i); // Render the number
        }
    }
};

SquareGenerator squareGenerator;
static bool isDragging = false;
static float offsetX = 0.0f;
static float offsetY = 0.0f;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    squareGenerator.draw();
    glFlush();
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        float mx = 2.0f * (static_cast<float>(x) / glutGet(GLUT_WINDOW_WIDTH)) - 1.0f;
        float my = 1.0f - 2.0f * (static_cast<float>(y) / glutGet(GLUT_WINDOW_HEIGHT));

        if (state == GLUT_DOWN) {
            for (int i = 1; i < squareGenerator.getSquares().size(); ++i) {
                auto& square = squareGenerator.getSquares()[i];
                if (mx >= square.x1 && mx <= square.x2 && my <= square.y1 && my >= square.y2) {
                    isDragging = true;
                    offsetX = mx - square.x1;
                    offsetY = my - square.y2;
                    break;
                }
            }
        } else if (state == GLUT_UP) {
            isDragging = false;
        }
    } else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
        if (squareGenerator.getSquares().size() == 1) {
            squareGenerator.generateSquare();
        } else {
            float mx = 2.0f * (static_cast<float>(x) / glutGet(GLUT_WINDOW_WIDTH)) - 1.0f;
            float my = 1.0f - 2.0f * (static_cast<float>(y) / glutGet(GLUT_WINDOW_HEIGHT));

            if (mx >= squareGenerator.getSquares()[0].x1 && mx <= squareGenerator.getSquares()[0].x2 &&
                my <= squareGenerator.getSquares()[0].y1 && my >= squareGenerator.getSquares()[0].y2) {
                squareGenerator.generateSquare();
            }
        }
    }

    glutPostRedisplay();
}

void motion(int x, int y) {
    if (isDragging) {
        float mx = 2.0f * (static_cast<float>(x) / glutGet(GLUT_WINDOW_WIDTH)) - 1.0f;
        float my = 1.0f - 2.0f * (static_cast<float>(y) / glutGet(GLUT_WINDOW_HEIGHT));

        std::vector<int> availableBoundaries; // Vector to store available boundary indices

        for (int i = 1; i < squareGenerator.getSquares().size(); ++i) {
            auto& square = squareGenerator.getSquares()[i];
            if (square.x1 <= mx && mx <= square.x2 && square.y2 <= my && my <= square.y1) {
                for (int j = 1; j < squareGenerator.getSquares().size(); ++j) {
                    if (i != j) {
                        auto& otherSquare = squareGenerator.getSquares()[j];
                        if (otherSquare.x1 <= mx && mx <= otherSquare.x2 && otherSquare.y2 <= my && my <= otherSquare.y1) {
                            // Mix colors
                            square.r = (square.r + otherSquare.r);
                            square.g = (square.g + otherSquare.g);
                            square.b = (square.b + otherSquare.b);

                            if(square.r == 2.0f && square.g == 2.0f && square.b == 2.0f){
                                square.r = 0.0f;
                                square.g = 0.0f;
                                square.b = 0.0f;
                            }

                            // Remove the other square
                            squareGenerator.getSquares().erase(squareGenerator.getSquares().begin() + j);
                            availableBoundaries.push_back(j); // Store the index of the available boundary
                            break;
                        }
                    }
                }
                float width = square.x2 - square.x1;
                float height = square.y1 - square.y2;
                square.x1 = mx - width / 2.0f;
                square.x2 = mx + width / 2.0f;
                square.y1 = my + height / 2.0f;
                square.y2 = my - height / 2.0f;
                break;
            }
        }

        // Remove the corresponding boundary index from the available boundaries vector
        for (int index : availableBoundaries) {
            squareGenerator.unusedBoundaries.push_back(index);
        }

        glutPostRedisplay();
    }
}

int main(int argc, char** argv) {
    srand(static_cast<unsigned int>(time(0)));
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("OpenGL - Top Left Square");
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutMainLoop();

    return 0;
}
